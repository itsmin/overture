# Working with Claude Code: From Single Projects to Orchestration

**Created**: March 22, 2026
**Context**: Reconstructed from a concept exploration session. The ideas are Min's — the framing, pushback, and structure reflect how this thinking develops in practice with Claude Code as a working partner.
**Purpose**: Portable reference for establishing Claude Code working patterns on any project. Drop this into a session to ground the collaboration.
**Companion to**: [Claude Code Workflow Framework](Workflow/Claude-Code-Workflow-Framework-Personal.md) (detailed session-level patterns)

---

## What's Actually Happening When You Use an LLM

Most people skip this. It matters.

When you type into a chat interface, you're doing **In-Context Learning (ICL)** — you're filling the model's working memory with information so it generates better responses *right now*. You're not training it. You're not teaching it. You're staging a desk.

The model's actual knowledge — its weights, parameters, the "metal" — was set during training at the AI lab, long before it reached you. **RLHF** (Reinforcement Learning from Human Feedback) is how that training happens: thousands of human raters rank responses, those rankings become a mathematical reward signal, and gradient descent permanently shifts billions of parameters. That's real learning. That's access to the metal.

What you're doing is something else entirely. You're handing a genius with amnesia the right stack of papers before each conversation.

### Why this distinction matters for workflow design

Every "memory" system built on top of an LLM is a workaround for ICL being ephemeral. Session-start scripts, CLAUDE.md files, documentation — these are all ways of manually loading context into a model that will forget everything the moment you close the window. That's not a flaw to work around. It's the fundamental constraint that shapes every architectural decision.

Once you accept that:
- **Context windows have limits** → you need to manage what's loaded, not dump everything in
- **More context ≠ better reasoning** → attention degrades in the middle of long prompts; curate, don't accumulate
- **The model doesn't learn from your corrections** → corrections must be encoded as persistent artifacts (CLAUDE.md, documentation) that reload every session
- **"Memory" features are automated ICL** → platforms that "remember" your preferences are just silently injecting stored notes into your prompt. The metal never moved.

### The honest version of "a million tokens of context"

It means the desk is bigger. You can spread out more documents before things fall off the edge. A larger desk doesn't make the researcher smarter. It also doesn't mean you should cover every square inch — a cluttered desk is worse than a focused one, regardless of surface area.

Loading 30,000 tokens of architecture docs when only 2,000 are relevant to today's work means 28,000 tokens of attention budget spent on noise. At scale, that noise costs money (token pricing) and quality (attention dilution).

---

## Memory Architecture

### The Problem

You need continuity between sessions. The naive solution: write everything down, load it all next time. Works until the files grow, context gets noisy, and the model starts missing instructions buried in walls of stale text.

### Three Tiers

**Tier 1 — Session Context (The Desk)**
The current conversation plus whatever's loaded via CLAUDE.md and session-start scripts. Dies when the session ends. The only lever you have is curation — load what's relevant, skip what isn't.

**Tier 2 — Active Documentation (The Filing Cabinet)**
CLAUDE.md, session progress, work queues, source-of-truth docs. Persists between sessions. Session-end scripts update these; session-start scripts load them. **This is where most of the workflow engineering happens.** The [Workflow Framework](Workflow/Claude-Code-Workflow-Framework-Personal.md) covers this tier in detail.

**Tier 3 — Archive (Cold Storage)**
Old session logs, completed work, historical context. Not loaded into sessions unless specifically needed. Exists for reference, not for reasoning.

### The Digestive System

Tier 2 files grow. Without pruning, they become walls of text the model skims past. The solution: automated pruning based on signals that approximate relevance.

**Parameters for culling decisions:**
- **Age** — How old is this information?
- **Magnitude** — How many sessions did this concept persist across? High magnitude signals a core truth. Don't cull it.
- **Last access** — When was this information last referenced in a session?
- **Grace period** — Culled items leave a pointer to the archive before full removal. Safety net for the transition.

This is cache eviction applied to documentation. LRU with a semantic layer. Not a research breakthrough — a practical recognition that **context management is a caching problem.**

**The honest part:** Things still get dropped. The mitigation isn't perfection — it's ensuring that dropped items are old enough that the impact is low. If you don't notice something's gone within the grace period, it probably wasn't load-bearing. That sounds hand-wavy. In practice, it works. The alternative — keeping everything forever — fails harder and fails silently (the model ignores your instructions because they're buried in noise, and you don't know it's happening).

---

## The Kit: Levels of Sophistication

Projects don't all need the same workflow overhead. A weekend script doesn't need session commands. A production product portfolio does. Match the investment to the need.

### Level 0: One-Shot

No persistent state. Open Claude Code, ask a question, close. Most tasks start here. Many should stay here.

### Level 1: Single Project, Basic Sessions

**What you need:**
- A `CLAUDE.md` at the project root with: guidelines, current state, work queue
- Discipline to update it manually at session end

**What you get:** The model knows your project context at session start. You can pick up where you left off, roughly. The gap between "roughly" and "reliably" is what Level 2 addresses.

### Level 2: Single Project, Mature

**What you add:**
- `.claude/commands/session-start.md` — automated context loading, metrics validation, work queue presentation
- `.claude/commands/session-end.md` — documentation sync checks, deferred work tracking, progress updates
- Sources of truth definitions — which file is authoritative for which data (prevents documentation drift)
- Deferred work tracking — bumped items get logged with context, not silently dropped

**What you get:** Reliable handoffs between sessions. Work doesn't disappear when priorities shift. Documentation stays honest because the session-end command forces a sync check.

**Reference:** The [Workflow Framework](Workflow/Claude-Code-Workflow-Framework-Personal.md) covers Level 1-2 patterns in full detail, including templates.

### Level 3: Single Project, Automated

**What you add:**
- The digestive system — scripted summarization and archival based on age, magnitude, access frequency
- Idle-time automation — cron-based test harness execution, linting, health checks that run when you're away
- Self-maintaining test harnesses — updated when code changes, so they catch regressions proactively

**What you get:** The project maintains itself between your active sessions. Context stays lean. Tests run without being asked. Stale documentation gets pruned before it becomes noise.

**Honest caveat:** Level 3 is custom engineering. There's no drop-in framework for this. The digestive system and idle-time automation are scripts you build for your specific workflow. The *pattern* is generalizable; the *implementation* isn't.

### Level 4: Multi-Project Coordination (Choral)

**What you add:**
- A coordination session with its own directory, CLAUDE.md, and mandate
- Working contracts between coordinated project pairs
- Cross-project references in each project's CLAUDE.md
- A human approval gate for architectural recommendations

**What you get:** Projects develop awareness of each other's capabilities without coupling their implementations. Integration opportunities surface architecturally — proposed in contracts, approved by you, implemented independently by each project session.

**Reference:** The Choral pattern (see below).

---

## The Choral Pattern

### The Problem It Solves

Solo developer, multiple products, each with its own Claude Code session. Each session is an amnesiac genius that knows its own codebase but has zero awareness of its siblings. You are the only relay between them. That works at small scale. It becomes a bottleneck when the projects need to interoperate.

### What It Is

A Claude Code session dedicated to reading multiple project codebases and writing architectural recommendations to a shared document. It observes. It proposes. It does not implement.

### How It Works

```
Choral reads Project A codebase
Choral reads Project B codebase
Choral identifies integration opportunities, risks, shared patterns
Choral writes recommendations to the working contract
     ↓
You approve, reject, or defer recommendations
     ↓
Project A session reads the contract → implements approved items
Project B session reads the contract → implements approved items
Project sessions update the contract with implementation status
```

### Design Principles

**Read-only observation.** Choral doesn't write to sibling codebases. The moment a coordinator starts touching implementation, you have too many cooks. The contract is the interface.

**Contract as single communication channel.** No back-channel, no probing, no "let me ask Project B's session about this." The contract is the shared artifact. Everything flows through it.

**Reference designs, not shared code.** When Choral identifies a pattern worth reusing across projects, it recommends following the *architecture* — not extracting a shared library. Shared code is premature until the second consumer proves the abstraction is correct. Build it twice, find the real overlap, *then* consider extraction.

**Provenance matters.** Different projects have different data trust models. A professional's self-reported work history is first-person authoritative. A company's news-extracted intelligence is third-party assembled. A coordination layer that treats these the same will produce bad recommendations.

**Human approval gate.** Choral proposes, you decide. No recommendation becomes work without explicit approval. This prevents the coordination layer from generating busywork that serves architectural elegance but not product goals.

### Making It Repeatable

The pattern is project-pair-agnostic. To coordinate a new pair:

1. Create a directory at the same level as the projects
2. Write a `CLAUDE.md` defining the mandate, boundaries, and read access
3. Create `.claude/commands/` for session-start (read both projects) and session-end (update contracts)
4. Create a contract document for the pair
5. Add cross-project coordination sections to both project CLAUDE.md files referencing the contract

Same pattern. Different projects. Different contracts. Different integration surfaces.

---

## Open Work

These aren't conclusions. They're the threads worth pulling in a dedicated working session.

### Architecture (First Choral Session)

1. **Company representation agent** — pxtxt's representation engine ("Lyrical") as reference design, purpose-built for company entities. Key tension: pxtxt's canonical data is built through interviews (first-person). BETA's is assembled from news, SEC filings, and LLM extraction (third-party). The representation agent's confidence model, guardrails, and refresh cadence will be fundamentally different.

2. **Company canonical data schema** — What constitutes "canonical" for a company? How does temporal decay work? (News decays in days, SWOT in weeks, entity metadata in months.) No interview pipeline, no claim approval — continuous assembly from external sources.

3. **BETA → pxtxt claim validation** — Can BETA's news timeline corroborate professional claims? ("You said you launched X at Company Y in Q3 2025 — here's the press coverage.") Highest-value, lowest-risk first integration.

4. **Expanded BETA API surface** — 3 endpoints today (validate, enrich, timeline). People index, relationships, trending, SEC events, earnings insights are all internal-only. Which should be exposed? REST expansion vs MCP server vs both.

5. **pxtxt → BETA enrichment (P2)** — Opt-in professional profiles enriching BETA's people index. Speculative. Requires a provenance/trust model before any implementation (self-reported data mixed with SEC-extracted data without clear attribution is a liability, not a feature).

### Framework Evolution

6. **Document the digestive system** — Currently custom scripts. Could be a reference pattern with guidelines for parameters (age thresholds, magnitude scoring, grace periods).

7. **Document idle-time automation** — Cron-based test harness execution. How test harnesses self-update when code changes. The pattern is generalizable even if the implementation isn't.

8. **Extract Choral into a standalone framework doc** — Once the BETA ↔ pxtxt coordination proves the pattern, make it portable. Same move as the Workflow Framework — a reference document anyone can drop into a new setup.

9. **Define the progression path** — How does a project move from Level 0 → Level 4? What signals that it's time to level up? (Probably: when you start losing context between sessions, when work gets dropped, when sibling projects start stepping on each other.)

### Honest Gaps

10. **Scaling is unproven.** Choral has only coordinated lightweight integrations so far. A major architectural change propagating across projects hasn't been stress-tested.

11. **The digestive system is lossy by design.** The bet is that old enough ≈ unimportant enough. This is a heuristic, not a guarantee.

12. **Contract drift is a discipline problem, not a technical one.** If a project session changes the integration surface without updating the contract, Choral reasons against stale state. No automated check catches this.

13. **No integration testing.** Choral reads code and reasons about compatibility. It can't run tests. A breaking API change won't be caught until deployment. This gap is known and accepted — Choral is an architect, not a CI pipeline.

---

## How to Use This Document

**Starting a new project?** Read the Kit section. Pick your level. Don't over-invest — a weekend project at Level 2 is wasted effort.

**Scaling an existing project?** Check if you're hitting the signals for leveling up: losing context, dropping work, documentation rot. Add the next level's infrastructure.

**Coordinating multiple projects?** Set up a Choral instance. Start with the contract. Read both codebases before proposing anything.

**Establishing a new Claude Code session?** Drop this file alongside the [Workflow Framework](Workflow/Claude-Code-Workflow-Framework-Personal.md) and the [Voice Reference](Voice/editorial_collaborator_prompt.md). Together, they define how you work (this doc), how sessions run (Workflow), and how you write (Voice).

---

*This is a working document. It captures patterns that work today. Update it when they don't.*
